//
//  JoeyBot.h
//  RobotWar
//
//  Created by MakeGamesWith.Us on 7/3/14.
//  Copyright (c) 2014 Apportable. All rights reserved.
//

#import "Robot.h"

@interface JoeyBot : Robot

@end
